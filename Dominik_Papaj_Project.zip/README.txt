This program is a basic banking simulator starting with three default users. 
You can add additional users by providing only a login and password;
user IDs are automatically generated. To log in, users need to provide their ID,
login, and password. Money transfers can be made to other accounts, 
and loans can be taken (with a requirement to repay twice the borrowed amount). 
Resetting the system returns it to its default state with only 
the original three accounts available.